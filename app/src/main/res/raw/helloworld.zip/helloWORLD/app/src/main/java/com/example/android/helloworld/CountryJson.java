package com.example.android.helloworld;

public interface CountryJson {
    String JSON_STRING = "{\"Nigeria\":{\"name\":\"nigeria\",\"image\":nigeria.png}}";
}
