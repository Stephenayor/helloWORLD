package com.example.android.helloworld;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Countries extends AppCompatActivity {

    private String imageContainer;
    ImageView imageView;
    static String json = "";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_countries);

        Button nigeria_btn = (Button) findViewById(R.id.nigeria_btn);
        ImageView imageView = (ImageView) findViewById(R.id.country_image);




        try {

            JSONObject obj = new JSONObject(json);

            JSONArray array = obj.getJSONArray("Countries");
            for (int i = 0; i < array.length(); i++) {
                String correctAnswer = array.getJSONObject(i).getString("name");
                String imageAnswer = array.getJSONObject(i).getString("image");
                int id = array.getJSONObject(i).getInt("id");

                List<String> optionList = new ArrayList<String>();
                optionList.add(array.getJSONObject(i).getString("options"));

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

//        @Override
//                public boolean equals(Object o);
//                Countries country = (Countries)o;
//                return imageContainer == country.imageContainer  && "nigeria.png";


            public void checkImage(View v) {
                if(imageContainer.equals("nigeria.png")){
                    // display this Toast
                    Toast toast = Toast.makeText(getApplicationContext(), "Correct", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.BOTTOM | Gravity.LEFT, 0, 0);
                    toast.show(); // show Toast
                }else { }
            }
        }





